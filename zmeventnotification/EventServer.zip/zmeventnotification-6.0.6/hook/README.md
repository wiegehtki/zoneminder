### What

Kung-fu machine learning goodness. 

This is an example of how you can use the `hook` feature of the notification server
to invoke a custom script on the event before it generates an alarm. 
I currently support object detection and face recognition. 

Please don't ask me questions on how to use them. Please read the comments and figure it out.

### Installation

Read the official docs [here](https://zmeventnotification.readthedocs.io/en/latest/guides/hooks.html)


